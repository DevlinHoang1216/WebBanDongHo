package fpt.assignment.asm_ts00471_sof3022;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsmTs00471Sof3022ApplicationTests {

    @Test
    void contextLoads() {
    }

}
