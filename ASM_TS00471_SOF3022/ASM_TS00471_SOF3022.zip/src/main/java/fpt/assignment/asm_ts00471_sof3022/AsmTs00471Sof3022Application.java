package fpt.assignment.asm_ts00471_sof3022;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AsmTs00471Sof3022Application {

    public static void main(String[] args) {
        SpringApplication.run(AsmTs00471Sof3022Application.class, args);
    }

}
