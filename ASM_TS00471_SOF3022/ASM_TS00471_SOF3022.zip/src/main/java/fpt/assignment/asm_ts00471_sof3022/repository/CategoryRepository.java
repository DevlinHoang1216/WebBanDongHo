package fpt.assignment.asm_ts00471_sof3022.repository;

import fpt.assignment.asm_ts00471_sof3022.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, Integer> {

}
